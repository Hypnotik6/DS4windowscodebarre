# TODO

* Change stick coordinate clamping for JoyCon. Make initial center offset on first input?
* Expose extra SL and SR buttons for JoyCon Joined mode. Keep using normal SL and SR for Split mode
* ~~Add hooks to keep track of active display monitors for Absolute Mouse~~
* ~~Figure out desired options for Absolute Mouse support~~
* ~~Add absolute mouse options for various output types (Sticks and Touchpad)~~
* Add more localization ready strings
* Try to add some form of Action Set support. Really missing playing Mass Effect 1 and 2
* ~~Add rotation option for Touchpad Mouse Joystick~~
* ~~Experiment with XmlSerializer class for reading Profiles.xml data~~
* ~~Re-check Switch Pro and JoyCon rumble frequency interpretation~~
* ~~Attempt to add stick delta acceleration for mouse output. Kind of missing that option from my old experiments~~

